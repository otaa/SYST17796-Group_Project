package cardgameweek4;


public class Card
{
    // Constants for representing colours
    public static final int COLOR_NONE = 0;
    public static final int COLOR_GREEN = 1;
    public static final int COLOR_BLUE = 2;
    public static final int COLOR_RED = 3;
    public static final int COLOR_YELLOW = 4;

    // An array of names indexed by the colours above
    public static final String[] COLOR_NAMES= {"", "Green","Blue","Red","Yellow"};
    protected int myColor;    
    private String mySymbol;
    
    // Create a card with a given colour and symbol
   
     //colour The card colour. Should be one of COLOUR_NONE, COLOUR_GREEN, COLOUR_BLUE, COLOUR_RED or COLOUR_YELLOW.
    
    public Card(int color, String symbol) {
        myColor = color;
        mySymbol = symbol;
    }

    //Create a card with a given colour and number
     //colour The card colour. Should be one of COLOUR_NONE, COLOUR_GREEN, COLOUR_BLUE, COLOUR_RED or COLOUR_YELLOW.
    // number The number on the card
    
    public Card(int color, int number) {
        myColor = color;
        mySymbol = "" + number;
    }
    
    // Get the colour of the card
    
    public int getColor() {
        return myColor;
    }

    // Set the colour of the card
   
    public void setColor(int color) {
        myColor = color;
    }

     //Get the symbol on the card.
   
   public String getSymbol() {
        return mySymbol;
    }
    
    // Check whether this card can be played on the given card. 
     //The card to be played on
     //returns true if either the colors or the symbols match
   
    public boolean canPlayOn(Card card) {        
        return (card.mySymbol.equals(mySymbol) || card.myColor == myColor);        
    }
    
    public void play(UnoGame game) {
        // Default: has no effect
    }
    
    // String representation of the card.
   
    public String toString() {
        String result;
        
        result = COLOR_NAMES[myColor];
        if (!result.isEmpty()) {
            result += " ";
        }
        result += mySymbol;
        return result;
    }
}