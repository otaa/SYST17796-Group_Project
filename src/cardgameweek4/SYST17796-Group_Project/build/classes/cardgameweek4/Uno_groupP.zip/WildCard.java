
package cardgameweek4;

/**
 *
 * @author Pysia
*/
public class WildCard extends Card{
   
     //Constructor for objects of class WildCard
    
    public WildCard(){
        super(COLOR_NONE,"Wild");
        
    }
    
    
     //Check whether this card can be played on the given card. 
    
    public boolean canPlayOn(Card card)  { 
        //change to current card's colour
        this.setColor(card.getColor());
        // wild card: it should always return true
        return true;       
    }
    

}
