/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardgameweek4;

import java.util.Scanner;

/**
 *
 * @author Pysia
 */
class GamePlay {
    private Player[] players = new Player[10];
     //that should have game logic
    
    
    public static void main(String[] args) {
         boolean isValid=false;
         char ch;
         boolean wantToPlay=false;
         
         
        UnoGame game = new UnoGame();
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to our Uno Game");
        int numPlayers = 0;
        
        do
        {
            System.out.println("Would you like to add another player to the game (yes or no) ?");
            String yesOrNo = sc.nextLine();
           
            System.out.println("Please enter a VALID name, name must have:");
            System.out.println("A length of at least 5");
            System.out.println("At least one digit");
            String name = sc.nextLine();
            if (checkLength(name))
            {
               isValid=true;
            }
            
            else if (yesOrNo.equalsIgnoreCase("yes")){
                wantToPlay = true;
            }
            else{
                wantToPlay = false;
            }
        }while(!isValid);
        System.out.println("Valid name, accepted!");
        System.out.println("Player added and want to play");
    }
    
    /**
     * A method to check whether a name is at least length 5
     * @param pass - the String to check
     * @return true if length is greater than or equals to 5 and false otherwise
     */
    public static boolean checkLength(String name)
    {
        if(name.length()>=5)
        {
            return true;
        }
        return false;
    }
    
    
    
    //checking for number
    public static boolean checkNumber(String name){
       for(int i = 0; i < name.length(); i++){  
    
        if(Character.isAlphabetic(name.charAt(i)) && (Character.isDigit(name.charAt(i)))){
        return true;
        }
       }
       return false;   
    }
   
    
}
