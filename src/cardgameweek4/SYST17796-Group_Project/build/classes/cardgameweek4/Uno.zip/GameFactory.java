/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardgameweek4;

/**
 *
 * @author Pysia
 */
public class GameFactory {
    //these could be handy if we have more than one kinds of games

   /* public Game createGame(String type)
    {
        Game game = null;
        if(type.equals("Uno"))
        {
            game = new UnoGame();
        }
        else if (type.equals("other"))
        {
                game = new OtherGame();
        }
        return game;
    }*/
}
